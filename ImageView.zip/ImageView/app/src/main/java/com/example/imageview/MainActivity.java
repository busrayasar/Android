package com.example.imageview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView img;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        define();
        click();
    }

    public void define(){
        img = findViewById(R.id.imageview);
        btn = findViewById(R.id.btnChange);
    }
    public void click(){
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            int rnd = (int)(Math.random()*5+1);
            System.out.println("Random: "+rnd);
            change(rnd);
            }
        });
    }
    public void change(int num){
        if (num ==1){
            img.setImageResource(R.drawable.bir);
        }else if (num == 2){
            img.setImageResource(R.drawable.iki);
        }else if (num == 3){
            img.setImageResource(R.drawable.uc);
        }else if (num ==4 ){
            img.setImageResource(R.drawable.dort);
        }else if (num == 5){
            img.setImageResource(R.drawable.bes);
        }

    }
}