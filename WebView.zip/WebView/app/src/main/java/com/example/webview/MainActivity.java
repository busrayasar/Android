package com.example.webview;
//Busra Yasar

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {
    // WebView elemanı ile web sitelerini uygulamalarımızda görüntüleyebiliriz.
    WebView wb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        define();
        //showUrl();
        showHtml();

    }
    public void define(){ //webview elemanımızı burada tanımladım.
        wb = findViewById(R.id.webview);

    }

    public void showUrl(){
        wb.loadUrl("https://www.google.com.tr/");
        wb.getSettings().setJavaScriptEnabled(true); //js codelarının çalışmasına izin vermek için

    }
    public void showHtml(){
        String htmlCode = "<html><head>WebView Html Page </head><body><h1>HTML</h1></body></html>";
        wb.loadData(htmlCode, "text/html", "UTF-8"); //html kodu çalıştırma
    }

}