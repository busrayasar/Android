package com.example.buttons;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //layoutun ekran tasarımı cihazda görünür olur
        define_button();
        funcButton();


    }

    private void define_button(){
        btn = (Button) findViewById(R.id.buton1);
    }
    private void funcButton(){
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Button is clicked");
            }
        });
    }

}
