package com.example.radiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioButton pic1radio, pic2radio, pic3radio, pic4radio;
    ImageView img;
    RadioGroup radioGroup;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        define();
       // func();
        takeId();
    }

    public void define() {
        pic1radio = findViewById(R.id.p1);
        pic2radio = findViewById(R.id.p2);
        pic3radio = findViewById(R.id.p3);
        pic4radio = findViewById(R.id.p4);
        img = findViewById(R.id.imageview);
        radioGroup = findViewById(R.id.radiogrp);
        btn = findViewById(R.id.buton);

    }
    public void takeId(){


       btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               int takenId = radioGroup.getCheckedRadioButtonId();
               changePic(takenId);
           }
       });
    }
    public void changePic(int takenid){
        if (takenid == R.id.p1){
            img.setImageResource(R.drawable.bir);
            Toast.makeText(getApplicationContext(), pic1radio.getText() +" is choosen.", Toast.LENGTH_LONG).show();
        }else if (takenid == R.id.p2){
            img.setImageResource(R.drawable.iki);
            Toast.makeText(getApplicationContext(), pic2radio.getText() +" is choosen.", Toast.LENGTH_LONG).show();
        }else if (takenid == R.id.p3){
            img.setImageResource(R.drawable.uc);
            Toast.makeText(getApplicationContext(), pic3radio.getText() +" is choosen.", Toast.LENGTH_LONG).show();
        }else if (takenid == R.id.p4){
            img.setImageResource(R.drawable.dort);
            Toast.makeText(getApplicationContext(), pic4radio.getText() +" is choosen.", Toast.LENGTH_LONG).show();
        }
    }
/*
    public void  func(){
        pic1radio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img.setImageResource(R.drawable.bir);
                Toast.makeText(getApplicationContext(), pic1radio.getText() +" is choosen.", Toast.LENGTH_LONG).show();
            }
        });

        pic2radio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            img.setImageResource(R.drawable.iki);
                Toast.makeText(getApplicationContext(), pic2radio.getText() +" is choosen.", Toast.LENGTH_LONG).show();
            }
        });
        pic3radio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img.setImageResource(R.drawable.uc);
                Toast.makeText(getApplicationContext(), pic3radio.getText() +" is choosen.", Toast.LENGTH_LONG).show();
            }
        });
        pic4radio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img.setImageResource(R.drawable.dort);
                Toast.makeText(getApplicationContext(), pic4radio.getText() +" is choosen.", Toast.LENGTH_LONG).show();
            }
        });
    }

 */
}