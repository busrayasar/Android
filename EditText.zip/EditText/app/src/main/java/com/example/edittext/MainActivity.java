package com.example.edittext;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    TextView textView;
    Button buton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        define();
        click();
    }

    private void define(){
        editText = findViewById(R.id.edittext);
        buton = findViewById(R.id.hesaplaButon);
        textView = findViewById(R.id.sonucText);

    }

    private void  click(){
        buton.setOnClickListener(new View.OnClickListener() { //Alt+Enter ile implement edilecek metodu seç
            @Override
            public void onClick(View view) {
                String value = editText.getText().toString();
                int factorialNum =Integer.parseInt(value);
                int factorial = calculate(factorialNum);

                textView.setText("Result: "+factorial);

            }
        });
    }
    private int calculate(int num){
        int a=1;
        int result = 1;
        for(int i=num; i>0 ; i--  ){
            result = result*i;
        }
        return result;
    }

}