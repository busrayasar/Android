package com.example.toastmsg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView image;
    Button button1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        define();
        isClick();

        //Toast.makeText(this, "Toast Message ", Toast.LENGTH_LONG).show();
        //getApplicationContext() bulunduğumuz classı temsil eder
    }
    public void define(){
        image = findViewById(R.id.img);
        button1 = findViewById(R.id.btn);
    }
    public void isClick(){
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int rand = (int) (Math.random()*5+1);
                change(rand);
                String text =""+String.valueOf(rand)+"th picture is shown ";
                Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT ).show();
                //this keywordü hata verdiği için onun yerine getApplicationContext() kullandık.
            }
        });
    }
    private void change(int r){
        switch (r){
            case 1:
                image.setImageResource(R.drawable.bir);
                break;
            case 2:
                image.setImageResource(R.drawable.iki);
                break;
            case 3:
                image.setImageResource(R.drawable.uc);
                break;
            case 4:
                image.setImageResource(R.drawable.dort);
                break;
            case 5:
                image.setImageResource(R.drawable.bes);
                break;
        }

    }

}